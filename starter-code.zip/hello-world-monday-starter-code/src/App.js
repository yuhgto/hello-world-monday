import React from 'react';
import './App.css';
import monday from 'monday-sdk-js';

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      settings: {},
      context: {},
      boardIds: [],
      itemCount: null,
    }
  }

  // initialize component with settings
  componentDidMount() {
    // TODO: add listeners
  }

  // bind settings to app state
  getSettings = res => {
    // TODO: set state
  }

  getContext = res => {
    // TODO: bind context and do something
  }

  countItems = res => {
    // TODO: count items on board
  }

  render() {
    return (
      <div
        className="App"
        >
        // Add content here
      </div>
    );
  }
}

export default App;
